import { useState } from "react"
import './FormFields.css';
import { Message } from "./Message";

export const FormFields = () =>
{

    const [inputValues, setInputValues] = useState({
        firstName: "",
        lastName: "",
        userName: "",
        email: "",
        password: ""
    })
    
    const [logedIn,setLogedIn] = useState(false)
    const [valid,setValid] = useState(false)
    const [filledInput,setFilledInput] = useState(false)
   
    const logInInfo = 
    {
        email: "test@gmail.com",
        password: "test12"
    }

    const submitHandler = (event) =>
    {
        event.preventDefault()
        if(inputValues.email === logInInfo.email && inputValues.password === logInInfo.password) 
        {
            setValid(true)            
        }
        setLogedIn(true)
        if(inputValues.email && inputValues.password && inputValues.firstName && inputValues.lastName && inputValues.userName)
        {
            setFilledInput(true)
        }
        console.log(inputValues.firstName)
        console.log(inputValues.lastName)
        console.log(inputValues.userName)
        console.log(inputValues.email)
        console.log(inputValues.password)
    }

    

    return (
        <div id="container">
            <div></div>
          
            <form id="form_container" onSubmit={submitHandler}>
    
                    First Name: <input 
                    type="text" 
                    onChange={(event) => setInputValues({...inputValues, firstName: event.target.value})}/>
                {logedIn && !inputValues.firstName ? <span>Please enter first name!</span> : null}
                <br></br>

                    Last Name: <input 
                    type="text"
                    onChange={(event) => setInputValues({...inputValues, lastName: event.target.value})}/>
                {logedIn && !inputValues.lastName ? <span>Please enter last name!</span> : null} 
                <br></br>

                    Username: <input 
                    type="text"
                    onChange={(event) => setInputValues({...inputValues, userName: event.target.value})}/>
                {logedIn && !inputValues.userName ? <span>Please enter username!</span> : null} 
                <br></br>

                    Email: <input 
                    type="email"
                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                    onChange={(event) => setInputValues({...inputValues, email: event.target.value})}/>
                {logedIn && !inputValues.email ? <span>Please enter email !</span> : null} 
                <br></br>

                    Password: <input 
                    type="password"
                    maxLength="6"
                    onChange={(event) => setInputValues({...inputValues, password: event.target.value})}/>
                {logedIn && !inputValues.password ? <span>Please enter a password!</span> : null} 
                <br></br>

                <button id="submitBtn" type="submit">Login</button>

                {logedIn && valid ? <Message 
                                     validOrNot="true"
                                     FirstName={inputValues.firstName}
                                     LastName={inputValues.lastName}
                                     UserName={inputValues.userName}
                                     Email={inputValues.email}
                                     Password={inputValues.password} /> : null }
                
                {logedIn && filledInput && !valid ? <Message validOrNot="false"/> : null}
    
            </form>
            
            <div></div>
        </div>
    )
}