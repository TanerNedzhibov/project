

export const Message = (props) =>
{

    const logInfoStyle = 
    {
        textAlign: "left"
    }



    return(
        <div>
            {props.validOrNot == "true" ? 
            <h1 style={logInfoStyle}>Logged in successfuly! <br></br>
                First name: {props.FirstName} <br></br>
                Last name: {props.LastName} <br></br>
                Username: {props.UserName} <br></br>
                Email: {props.Email} <br></br>
                Password: {props.Password} <br></br>
            </h1> : null}
            {props.validOrNot == "false" ? 
            <h1>Login failed!</h1> : null}
        </div>
    )
}