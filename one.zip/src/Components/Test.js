import { useState } from "react"

export const Test = (props) =>
{
    const [info2,setInfo] = useState(
        {
            name: "Taner",
            age: 28,
            mf: "Male"
        }
    )

    

    const submitHandler = (event) =>
    {
        event.preventDefault()
        if(info2)
        {
            props.passingInfo(info2)
        }
    }

    return (
        <div>
            <form onSubmit={submitHandler}>
                <input type="Text" onChange={(event) => setInfo(event.target.value)}/>
                <button type="submit">CLick</button>
                
            </form>
            
        </div>
    )
}